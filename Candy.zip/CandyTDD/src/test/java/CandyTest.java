import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * A JUnit test case class.
 * Every method starting with the word "test" will be called when running
 * the test with JUnit.
 *
<!--//# BEGIN TODO: Name, student ID, and date-->

    Name: Paulo Vieira 
    Student ID: 1798618
    Date: 2025-05-05
  
<!--//# END TODO-->
 */
public class CandyTest {
 
    static final Candy SUT = new Candy(); 

    static final long MAX_VALUE = 999999999999999999L; 

    private void check(long k, long c, boolean expected) {
        System.out.println("divide(" + k + ", " + c + ")");
        long result = SUT.divide(k, c);
        System.out.println("  result = " + result);
        assertEquals(expected, 0 <= result, "possible (0 <= result)");
        if (0 <= result) {
            assertTrue(result <= MAX_VALUE, "range (result <= MAX_VALUE)");
            assertEquals(result * k, c, "quotient (result * k == c)");
        }
    }

    // Test cases

    @Test
    public void testDivideGivenExample() {
        check(3, 15, true);
    }

//# BEGIN TODO: Additional test cases
    @Test
    public void testDivideExactDivision() {
        check(5, 25, true); 
    }

    @Test
    public void testDivideNotDivisible() {
        check(4, 10, false); 
    }

    @Test
    public void testDivideNegativeCandies() {
        check(3, -9, false); 
    }

    @Test
    public void testDivideNegativeKids() {
        check(-3, 9, false); 
    }

    @Test
    public void testDivideNegativeBoth() {
        check(-3, -9, false); 
    }

    @Test
    public void testDivideLargeExact() {
        check(1000000000L, 500000000000000000L, true); 
    }

    @Test
    public void testDivideLargeInvalid() {
        check(999999999999999998L, 999999999999999999L, false); 
    }

    @Test
    public void testDivideZeroKidsZeroCandies() {
        check(0, 0, true); 
    }

    @Test
    public void testDivideZeroKidsNonzeroCandies() {
        check(0, 5, false); 
    }

    @Test
    public void testDivideZeroCandies() {
        check(10, 0, true); 
    }

    @Test
    public void testDivideOneKid() {
        check(1, 999999999999999999L, true);
    }
    
//# END TODO

}
